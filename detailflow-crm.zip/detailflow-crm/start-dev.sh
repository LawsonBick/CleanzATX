#!/bin/bash
export NVM_DIR="$HOME/.nvm"
[ -s "$NVM_DIR/nvm.sh" ] && \. "$NVM_DIR/nvm.sh"
cd "/Users/user/Desktop/CleanzATX Claude Code/detailflow-crm"
npx next dev --port 3001
