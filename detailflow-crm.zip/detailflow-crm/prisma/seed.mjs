import { PrismaClient } from "@prisma/client";

const prisma = new PrismaClient();

async function main() {
  // Clear existing data
  await prisma.activityLog.deleteMany();
  await prisma.messageLog.deleteMany();
  await prisma.sequenceEnrollment.deleteMany();
  await prisma.job.deleteMany();
  await prisma.sequenceStep.deleteMany();
  await prisma.nurtureSequence.deleteMany();
  await prisma.contact.deleteMany();
  await prisma.businessProfile.deleteMany();

  // Business Profile
  await prisma.businessProfile.create({
    data: {
      name: "Texas Auto Club Mobile Detailing",
      phone: "(512) 555-0199",
      email: "info@texasautoclub.com",
      businessHours: JSON.stringify({ start: "08:00", end: "18:00", days: [1, 2, 3, 4, 5, 6] }),
      optOutKeywords: "STOP,UNSUBSCRIBE,CANCEL,QUIT",
    },
  });

  // Default Nurture Sequence
  const sequence = await prisma.nurtureSequence.create({
    data: {
      name: "Default Detailing Nurture",
      isDefault: true,
    },
  });

  const steps = [
    { order: 0, delayDays: 0, channel: "SMS", subject: "", template: "Hey [FirstName]! This is [BusinessName]. Thanks for reaching out about detailing services. I'd love to get your [VehicleYear] [VehicleMake] looking amazing. When works best for you? Reply STOP to opt out." },
    { order: 1, delayDays: 1, channel: "Email", subject: "Still thinking about it?", template: "Hi [FirstName],\n\nI wanted to follow up about your [VehicleYear] [VehicleMake] [VehicleModel]. We specialize in [ServiceInterest] and would love to help you out.\n\nOur team at [BusinessName] takes pride in every vehicle we touch. We use premium products and pay attention to every detail.\n\nWhen would be a good time to schedule your appointment?\n\nBest regards,\n[BusinessName]" },
    { order: 2, delayDays: 3, channel: "SMS", subject: "", template: "Hey [FirstName], just checking in! We have availability this week. Want to lock in a spot? 🚗" },
    { order: 3, delayDays: 7, channel: "Email", subject: "What we did for other [VehicleMake] owners", template: "Hi [FirstName],\n\nI wanted to share some results from other [VehicleMake] owners who trusted us with their vehicles.\n\nOur [ServiceInterest] service has been a game-changer for customers like you. The transformation is incredible — from dull and tired to showroom-fresh.\n\nWe'd love to do the same for your [VehicleYear] [VehicleMake] [VehicleModel].\n\nReady to see the difference? Just reply to book your spot.\n\n[BusinessName]" },
    { order: 4, delayDays: 14, channel: "SMS", subject: "", template: "Hey [FirstName]! Quick heads up — we're offering 10% off [ServiceInterest] if you book this week. Your [VehicleMake] deserves it! 💎" },
    { order: 5, delayDays: 21, channel: "Email", subject: "5 Signs Your Car Needs a Detail", template: "Hi [FirstName],\n\n5 signs your car needs professional detailing:\n\n1. Water doesn't bead on the paint anymore\n2. You can write your name in the dust on the dashboard\n3. The interior smells like last week's drive-thru\n4. Swirl marks are visible in direct sunlight\n5. You can't remember the last time it was detailed\n\nSound familiar? We can fix all of that with our [ServiceInterest] service.\n\nLet us know when you're ready!\n\n[BusinessName]" },
    { order: 6, delayDays: 30, channel: "SMS", subject: "", template: "Hey [FirstName], still interested in getting your [VehicleYear] [VehicleMake] detailed? We'd love to help whenever you're ready!" },
    { order: 7, delayDays: 45, channel: "Email", subject: "We'd hate to see you go", template: "Hi [FirstName],\n\nWe haven't heard from you in a while, and we understand — life gets busy!\n\nBut your [VehicleYear] [VehicleMake] [VehicleModel] still deserves some love. If you're still interested in [ServiceInterest], we're here whenever you're ready.\n\nIf not, no hard feelings at all. Just reply and let us know either way.\n\nTake care,\n[BusinessName]" },
    { order: 8, delayDays: 60, channel: "SMS", subject: "", template: "Hey [FirstName], it's been a while! We're running a special this month on [ServiceInterest]. Want to hear about it? Your [VehicleMake] is waiting! 🌟" },
  ];

  for (const step of steps) {
    await prisma.sequenceStep.create({
      data: { sequenceId: sequence.id, ...step },
    });
  }

  // Sample Leads
  const leads = [
    { firstName: "Marcus", lastName: "Johnson", phone: "(512) 555-0101", email: "marcus.j@gmail.com", source: "Google Ads", vehicleYear: "2023", vehicleMake: "BMW", vehicleModel: "X5", vehicleColor: "Black", serviceInterest: "Full Detail", status: "New" },
    { firstName: "Sarah", lastName: "Williams", phone: "(512) 555-0102", email: "sarah.w@yahoo.com", source: "Instagram", vehicleYear: "2024", vehicleMake: "Tesla", vehicleModel: "Model 3", vehicleColor: "White", serviceInterest: "Ceramic Coating", status: "New" },
    { firstName: "David", lastName: "Chen", phone: "(512) 555-0103", email: "dchen@outlook.com", source: "Facebook", vehicleYear: "2022", vehicleMake: "Toyota", vehicleModel: "Camry", vehicleColor: "Silver", serviceInterest: "Interior Only", status: "Contacted" },
    { firstName: "Ashley", lastName: "Rodriguez", phone: "(512) 555-0104", email: "ashley.r@gmail.com", source: "Referral", vehicleYear: "2023", vehicleMake: "Honda", vehicleModel: "Accord", vehicleColor: "Blue", serviceInterest: "Full Detail", status: "Contacted" },
    { firstName: "James", lastName: "Mitchell", phone: "(512) 555-0105", email: "jmitchell@gmail.com", source: "Google Ads", vehicleYear: "2024", vehicleMake: "Ford", vehicleModel: "F-150", vehicleColor: "Red", serviceInterest: "Exterior Only", status: "Nurturing" },
    { firstName: "Lisa", lastName: "Thompson", phone: "(512) 555-0106", email: "lisa.t@hotmail.com", source: "Walk-in", vehicleYear: "2021", vehicleMake: "Mercedes", vehicleModel: "C300", vehicleColor: "Gray", serviceInterest: "Paint Correction", status: "Nurturing" },
    { firstName: "Tyler", lastName: "Brown", phone: "(512) 555-0107", email: "tbrown@yahoo.com", source: "Instagram", vehicleYear: "2023", vehicleMake: "Chevrolet", vehicleModel: "Corvette", vehicleColor: "Yellow", serviceInterest: "Ceramic Coating", status: "Nurturing" },
    { firstName: "Rachel", lastName: "Davis", phone: "(512) 555-0108", email: "rachel.d@gmail.com", source: "Facebook", vehicleYear: "2022", vehicleMake: "Audi", vehicleModel: "Q5", vehicleColor: "White", serviceInterest: "Full Detail", status: "Quoted" },
    { firstName: "Kevin", lastName: "Lee", phone: "(512) 555-0109", email: "klee@outlook.com", source: "Google Ads", vehicleYear: "2024", vehicleMake: "Porsche", vehicleModel: "Cayenne", vehicleColor: "Black", serviceInterest: "Paint Correction", status: "Quoted" },
    { firstName: "Amanda", lastName: "Garcia", phone: "(512) 555-0110", email: "agarcia@gmail.com", source: "Referral", vehicleYear: "2023", vehicleMake: "Lexus", vehicleModel: "RX 350", vehicleColor: "Pearl White", serviceInterest: "Full Detail", status: "New" },
    { firstName: "Chris", lastName: "Martin", phone: "(512) 555-0111", email: "", source: "Walk-in", vehicleYear: "2020", vehicleMake: "Dodge", vehicleModel: "Charger", vehicleColor: "Black", serviceInterest: "Exterior Only", status: "Contacted" },
    { firstName: "Megan", lastName: "Taylor", phone: "(512) 555-0112", email: "mtaylor@gmail.com", source: "Instagram", vehicleYear: "2024", vehicleMake: "Jeep", vehicleModel: "Wrangler", vehicleColor: "Green", serviceInterest: "Interior Only", status: "New" },
    { firstName: "Brandon", lastName: "Anderson", phone: "(512) 555-0113", email: "brandon.a@yahoo.com", source: "Facebook", vehicleYear: "2022", vehicleMake: "Nissan", vehicleModel: "Altima", vehicleColor: "Gray", serviceInterest: "Full Detail", status: "Opted Out" },
    { firstName: "Nicole", lastName: "Harris", phone: "(512) 555-0114", email: "nharris@gmail.com", source: "Google Ads", vehicleYear: "2023", vehicleMake: "Hyundai", vehicleModel: "Tucson", vehicleColor: "Blue", serviceInterest: "Ceramic Coating", status: "Lost" },
    { firstName: "Daniel", lastName: "Clark", phone: "(512) 555-0115", email: "dclark@outlook.com", source: "Referral", vehicleYear: "2021", vehicleMake: "Subaru", vehicleModel: "Outback", vehicleColor: "Green", serviceInterest: "Full Detail", status: "Nurturing" },
  ];

  const createdLeads = [];
  for (let i = 0; i < leads.length; i++) {
    const lead = leads[i];
    const createdAt = new Date();
    createdAt.setDate(createdAt.getDate() - Math.floor(Math.random() * 30));

    const contact = await prisma.contact.create({
      data: { ...lead, type: "Lead", createdAt },
    });
    createdLeads.push(contact);

    if (!["Opted Out", "Lost"].includes(lead.status)) {
      const stepIndex = ["New", "Contacted", "Nurturing", "Quoted"].indexOf(lead.status);
      const dueDate = new Date();
      dueDate.setDate(dueDate.getDate() + Math.floor(Math.random() * 3));

      await prisma.sequenceEnrollment.create({
        data: {
          contactId: contact.id,
          sequenceId: sequence.id,
          currentStepOrder: Math.min(stepIndex + Math.floor(Math.random() * 3), steps.length - 1),
          status: "Active",
          nextDueDate: dueDate,
          enrolledAt: createdAt,
        },
      });
    } else if (lead.status === "Opted Out") {
      await prisma.sequenceEnrollment.create({
        data: {
          contactId: contact.id,
          sequenceId: sequence.id,
          currentStepOrder: 3,
          status: "OptedOut",
          enrolledAt: createdAt,
        },
      });
    }

    await prisma.activityLog.create({
      data: {
        contactId: contact.id,
        type: "lead_added",
        message: `New lead: ${lead.firstName} ${lead.lastName} - ${lead.vehicleYear} ${lead.vehicleMake} ${lead.vehicleModel}`,
        createdAt: createdAt,
      },
    });
  }

  // 3 Converted Customers
  const customers = [
    {
      firstName: "Michael", lastName: "Rivera", phone: "(512) 555-0120", email: "mrivera@gmail.com",
      source: "Google Ads", vehicleYear: "2023", vehicleMake: "Mercedes", vehicleModel: "GLE 350",
      vehicleColor: "Black", serviceInterest: "Full Detail",
      jobs: [
        { service: "Full Detail", price: 250, daysAgo: 90, notes: "First detail, customer very happy" },
        { service: "Interior Only", price: 120, daysAgo: 45, notes: "Quick interior refresh" },
        { service: "Ceramic Coating", price: 800, daysAgo: 10, notes: "Full ceramic coating package" },
      ],
    },
    {
      firstName: "Jennifer", lastName: "Patel", phone: "(512) 555-0121", email: "jpatel@outlook.com",
      source: "Referral", vehicleYear: "2024", vehicleMake: "BMW", vehicleModel: "X3",
      vehicleColor: "Alpine White", serviceInterest: "Ceramic Coating",
      jobs: [
        { service: "Full Detail", price: 275, daysAgo: 120, notes: "Pre-coating detail" },
        { service: "Ceramic Coating", price: 900, daysAgo: 115, notes: "5-year ceramic coating" },
        { service: "Exterior Only", price: 100, daysAgo: 30, notes: "Maintenance wash" },
      ],
    },
    {
      firstName: "Robert", lastName: "Nguyen", phone: "(512) 555-0122", email: "rnguyen@yahoo.com",
      source: "Instagram", vehicleYear: "2022", vehicleMake: "Porsche", vehicleModel: "911",
      vehicleColor: "Guards Red", serviceInterest: "Paint Correction",
      jobs: [
        { service: "Paint Correction", price: 600, daysAgo: 60, notes: "Two-stage paint correction" },
        { service: "Ceramic Coating", price: 1200, daysAgo: 55, notes: "Premium ceramic package" },
      ],
    },
  ];

  for (const customer of customers) {
    const createdAt = new Date();
    createdAt.setDate(createdAt.getDate() - 150);
    const totalValue = customer.jobs.reduce((sum, j) => sum + j.price, 0);
    const nextFollowUp = new Date();
    nextFollowUp.setDate(nextFollowUp.getDate() + 14);

    const contact = await prisma.contact.create({
      data: {
        firstName: customer.firstName, lastName: customer.lastName,
        phone: customer.phone, email: customer.email, source: customer.source,
        vehicleYear: customer.vehicleYear, vehicleMake: customer.vehicleMake,
        vehicleModel: customer.vehicleModel, vehicleColor: customer.vehicleColor,
        serviceInterest: customer.serviceInterest,
        status: "Converted", type: "Customer",
        totalLifetimeValue: totalValue,
        nextFollowUpDate: nextFollowUp,
        createdAt,
      },
    });

    for (const job of customer.jobs) {
      const jobDate = new Date();
      jobDate.setDate(jobDate.getDate() - job.daysAgo);
      await prisma.job.create({
        data: { contactId: contact.id, service: job.service, price: job.price, notes: job.notes, date: jobDate },
      });
    }

    await prisma.sequenceEnrollment.create({
      data: {
        contactId: contact.id, sequenceId: sequence.id,
        currentStepOrder: steps.length, status: "Completed", enrolledAt: createdAt,
      },
    });

    await prisma.activityLog.create({
      data: {
        contactId: contact.id, type: "converted",
        message: `${customer.firstName} ${customer.lastName} converted to customer!`,
        createdAt: new Date(createdAt.getTime() + 7 * 24 * 60 * 60 * 1000),
      },
    });
  }

  // Sample message logs
  const sampleMessages = [
    { channel: "SMS", status: "Sent" },
    { channel: "Email", status: "Opened" },
    { channel: "SMS", status: "Replied" },
    { channel: "Email", status: "Sent" },
    { channel: "SMS", status: "Sent" },
  ];

  for (let i = 0; i < Math.min(5, createdLeads.length); i++) {
    const lead = createdLeads[i];
    const msg = sampleMessages[i];
    const sentAt = new Date();
    sentAt.setDate(sentAt.getDate() - Math.floor(Math.random() * 7));

    await prisma.messageLog.create({
      data: {
        contactId: lead.id, channel: msg.channel,
        subject: msg.channel === "Email" ? "Following up on your detailing inquiry" : "",
        content: `Hey ${lead.firstName}! This is Texas Auto Club Mobile Detailing. Thanks for reaching out about detailing services. I'd love to get your ${lead.vehicleYear} ${lead.vehicleMake} looking amazing. When works best for you?`,
        status: msg.status, sentAt,
      },
    });

    await prisma.activityLog.create({
      data: {
        contactId: lead.id, type: "follow_up_sent",
        message: `${msg.channel} sent to ${lead.firstName} ${lead.lastName}`,
        createdAt: sentAt,
      },
    });
  }

  console.log("Seed data created successfully!");
  console.log("- 1 business profile");
  console.log("- 1 nurture sequence with 9 steps");
  console.log("- 15 sample leads");
  console.log("- 3 converted customers with job history");
  console.log("- Sample message logs and activity");
}

main()
  .catch(console.error)
  .finally(() => prisma.$disconnect());
