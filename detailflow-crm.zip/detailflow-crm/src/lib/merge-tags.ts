interface MergeData {
  firstName?: string;
  lastName?: string;
  vehicleYear?: string;
  vehicleMake?: string;
  vehicleModel?: string;
  serviceInterest?: string;
  businessName?: string;
}

export function mergeTags(template: string, data: MergeData): string {
  return template
    .replace(/\[FirstName\]/g, data.firstName || "")
    .replace(/\[LastName\]/g, data.lastName || "")
    .replace(/\[BusinessName\]/g, data.businessName || "Texas Auto Club Mobile Detailing")
    .replace(/\[VehicleYear\]/g, data.vehicleYear || "")
    .replace(/\[VehicleMake\]/g, data.vehicleMake || "")
    .replace(/\[VehicleModel\]/g, data.vehicleModel || "")
    .replace(/\[ServiceInterest\]/g, data.serviceInterest || "");
}
