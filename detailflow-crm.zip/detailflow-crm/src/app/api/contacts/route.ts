import { prisma } from "@/lib/db";
import { NextRequest, NextResponse } from "next/server";

export async function GET(req: NextRequest) {
  const url = new URL(req.url);
  const type = url.searchParams.get("type");
  const status = url.searchParams.get("status");
  const search = url.searchParams.get("search");

  const where: Record<string, unknown> = {};
  if (type) where.type = type;
  if (status) where.status = status;
  if (search) {
    where.OR = [
      { firstName: { contains: search } },
      { lastName: { contains: search } },
      { phone: { contains: search } },
      { email: { contains: search } },
      { vehicleMake: { contains: search } },
    ];
  }

  const contacts = await prisma.contact.findMany({
    where,
    include: {
      jobs: { orderBy: { date: "desc" } },
      sequenceEnrollments: {
        include: { sequence: { include: { steps: { orderBy: { order: "asc" } } } } },
      },
    },
    orderBy: { createdAt: "desc" },
  });

  return NextResponse.json(contacts);
}

export async function POST(req: NextRequest) {
  const body = await req.json();

  const contact = await prisma.contact.create({
    data: {
      firstName: body.firstName,
      lastName: body.lastName || "",
      phone: body.phone,
      email: body.email || "",
      source: body.source || "Other",
      vehicleYear: body.vehicleYear || "",
      vehicleMake: body.vehicleMake || "",
      vehicleModel: body.vehicleModel || "",
      vehicleColor: body.vehicleColor || "",
      serviceInterest: body.serviceInterest || "",
      notes: body.notes || "",
      status: "New",
      type: "Lead",
    },
  });

  // Auto-enroll in default nurture sequence
  const defaultSequence = await prisma.nurtureSequence.findFirst({
    where: { isDefault: true },
    include: { steps: { orderBy: { order: "asc" } } },
  });

  if (defaultSequence && defaultSequence.steps.length > 0) {
    const firstStep = defaultSequence.steps[0];
    const nextDue = new Date();
    nextDue.setDate(nextDue.getDate() + firstStep.delayDays);

    await prisma.sequenceEnrollment.create({
      data: {
        contactId: contact.id,
        sequenceId: defaultSequence.id,
        currentStepOrder: 0,
        status: "Active",
        nextDueDate: nextDue,
      },
    });
  }

  await prisma.activityLog.create({
    data: {
      contactId: contact.id,
      type: "lead_added",
      message: `New lead added: ${contact.firstName} ${contact.lastName} - ${contact.vehicleYear} ${contact.vehicleMake} ${contact.vehicleModel}`,
    },
  });

  return NextResponse.json(contact, { status: 201 });
}
