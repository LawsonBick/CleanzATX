import { prisma } from "@/lib/db";
import { NextRequest, NextResponse } from "next/server";

export async function POST(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;
  const body = await req.json();

  const job = await prisma.job.create({
    data: {
      contactId: id,
      service: body.service,
      price: parseFloat(body.price),
      notes: body.notes || "",
      date: new Date(body.date),
    },
  });

  // Update lifetime value
  const jobs = await prisma.job.findMany({ where: { contactId: id } });
  const totalValue = jobs.reduce((sum, j) => sum + j.price, 0);
  await prisma.contact.update({
    where: { id },
    data: { totalLifetimeValue: totalValue },
  });

  return NextResponse.json(job, { status: 201 });
}
