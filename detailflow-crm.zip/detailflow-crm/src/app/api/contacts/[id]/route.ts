import { prisma } from "@/lib/db";
import { NextRequest, NextResponse } from "next/server";

export async function GET(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;
  const contact = await prisma.contact.findUnique({
    where: { id },
    include: {
      jobs: { orderBy: { date: "desc" } },
      messageLogs: { orderBy: { sentAt: "desc" } },
      sequenceEnrollments: {
        include: { sequence: { include: { steps: { orderBy: { order: "asc" } } } } },
      },
      activityLogs: { orderBy: { createdAt: "desc" } },
    },
  });

  if (!contact) return NextResponse.json({ error: "Not found" }, { status: 404 });
  return NextResponse.json(contact);
}

export async function PATCH(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;
  const body = await req.json();

  const oldContact = await prisma.contact.findUnique({ where: { id } });
  if (!oldContact) return NextResponse.json({ error: "Not found" }, { status: 404 });

  const contact = await prisma.contact.update({
    where: { id },
    data: body,
  });

  if (body.status && body.status !== oldContact.status) {
    await prisma.activityLog.create({
      data: {
        contactId: id,
        type: "status_changed",
        message: `Status changed from ${oldContact.status} to ${body.status} for ${contact.firstName} ${contact.lastName}`,
      },
    });

    if (body.status === "Converted" && oldContact.type === "Lead") {
      await prisma.contact.update({ where: { id }, data: { type: "Customer" } });
      await prisma.sequenceEnrollment.updateMany({
        where: { contactId: id, status: "Active" },
        data: { status: "Completed" },
      });
      await prisma.activityLog.create({
        data: {
          contactId: id,
          type: "converted",
          message: `${contact.firstName} ${contact.lastName} converted to customer!`,
        },
      });
    }

    if (body.status === "Opted Out") {
      await prisma.sequenceEnrollment.updateMany({
        where: { contactId: id, status: "Active" },
        data: { status: "OptedOut" },
      });
    }
  }

  return NextResponse.json(contact);
}

export async function DELETE(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;
  await prisma.contact.delete({ where: { id } });
  return NextResponse.json({ ok: true });
}
