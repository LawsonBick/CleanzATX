import { prisma } from "@/lib/db";
import { NextRequest, NextResponse } from "next/server";

export async function GET(req: NextRequest) {
  const url = new URL(req.url);
  const contactId = url.searchParams.get("contactId");
  const channel = url.searchParams.get("channel");
  const search = url.searchParams.get("search");

  const where: Record<string, unknown> = {};
  if (contactId) where.contactId = contactId;
  if (channel) where.channel = channel;
  if (search) {
    where.OR = [
      { content: { contains: search } },
      { subject: { contains: search } },
    ];
  }

  const messages = await prisma.messageLog.findMany({
    where,
    include: { contact: true },
    orderBy: { sentAt: "desc" },
    take: 200,
  });

  return NextResponse.json(messages);
}
