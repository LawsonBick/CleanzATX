import { prisma } from "@/lib/db";
import { NextRequest, NextResponse } from "next/server";

export async function GET() {
  const sequences = await prisma.nurtureSequence.findMany({
    include: {
      steps: { orderBy: { order: "asc" } },
      _count: { select: { enrollments: true } },
    },
    orderBy: { createdAt: "desc" },
  });

  return NextResponse.json(sequences);
}

export async function POST(req: NextRequest) {
  const body = await req.json();

  const sequence = await prisma.nurtureSequence.create({
    data: {
      name: body.name,
      isDefault: body.isDefault || false,
    },
  });

  return NextResponse.json(sequence, { status: 201 });
}
