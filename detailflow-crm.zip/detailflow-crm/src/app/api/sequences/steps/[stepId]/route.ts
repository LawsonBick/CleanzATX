import { prisma } from "@/lib/db";
import { NextRequest, NextResponse } from "next/server";

export async function DELETE(
  _req: NextRequest,
  { params }: { params: Promise<{ stepId: string }> }
) {
  const { stepId } = await params;
  await prisma.sequenceStep.delete({ where: { id: stepId } });
  return NextResponse.json({ ok: true });
}
