import { prisma } from "@/lib/db";
import { NextRequest, NextResponse } from "next/server";

export async function POST(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;
  const body = await req.json();

  // Get max order
  const maxStep = await prisma.sequenceStep.findFirst({
    where: { sequenceId: id },
    orderBy: { order: "desc" },
  });

  const step = await prisma.sequenceStep.create({
    data: {
      sequenceId: id,
      order: (maxStep?.order ?? -1) + 1,
      delayDays: body.delayDays,
      channel: body.channel,
      subject: body.subject || "",
      template: body.template,
    },
  });

  return NextResponse.json(step, { status: 201 });
}

export async function PUT(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;
  const body = await req.json();

  // Bulk update steps (for reordering)
  if (Array.isArray(body.steps)) {
    for (const step of body.steps) {
      await prisma.sequenceStep.update({
        where: { id: step.id },
        data: {
          order: step.order,
          delayDays: step.delayDays,
          channel: step.channel,
          subject: step.subject || "",
          template: step.template,
        },
      });
    }

    const updated = await prisma.nurtureSequence.findUnique({
      where: { id },
      include: { steps: { orderBy: { order: "asc" } } },
    });

    return NextResponse.json(updated);
  }

  return NextResponse.json({ error: "Invalid body" }, { status: 400 });
}
