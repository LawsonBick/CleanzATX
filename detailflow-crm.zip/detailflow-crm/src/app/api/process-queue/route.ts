import { prisma } from "@/lib/db";
import { mergeTags } from "@/lib/merge-tags";
import { NextResponse } from "next/server";

export async function POST() {
  const now = new Date();

  // Find all active enrollments with due dates <= now
  const dueEnrollments = await prisma.sequenceEnrollment.findMany({
    where: {
      status: "Active",
      nextDueDate: { lte: now },
    },
    include: {
      contact: true,
      sequence: { include: { steps: { orderBy: { order: "asc" } } } },
    },
  });

  const business = await prisma.businessProfile.findFirst();
  const businessName = business?.name || "Texas Auto Club Mobile Detailing";

  let processed = 0;

  for (const enrollment of dueEnrollments) {
    const { contact, sequence } = enrollment;
    const steps = sequence.steps;

    if (steps.length === 0) continue;

    // Check if contact has opted out
    if (contact.status === "Opted Out" || contact.status === "Converted") {
      await prisma.sequenceEnrollment.update({
        where: { id: enrollment.id },
        data: { status: contact.status === "Opted Out" ? "OptedOut" : "Completed" },
      });
      continue;
    }

    let stepIndex = enrollment.currentStepOrder;
    let loopCount = enrollment.loopCount;

    // If we've gone past all steps, loop back (every 30 days after step 60)
    if (stepIndex >= steps.length) {
      stepIndex = steps.length - 1; // Use last step as rotating message
      loopCount += 1;
    }

    const step = steps[stepIndex];
    if (!step) continue;

    const mergedContent = mergeTags(step.template, {
      firstName: contact.firstName,
      lastName: contact.lastName,
      vehicleYear: contact.vehicleYear,
      vehicleMake: contact.vehicleMake,
      vehicleModel: contact.vehicleModel,
      serviceInterest: contact.serviceInterest,
      businessName,
    });

    // Simulate random statuses
    const statuses = ["Sent", "Sent", "Sent", "Opened", "Opened", "Replied"];
    const randomStatus = statuses[Math.floor(Math.random() * statuses.length)];

    // Create message log
    await prisma.messageLog.create({
      data: {
        contactId: contact.id,
        channel: step.channel,
        subject: step.subject ? mergeTags(step.subject, {
          firstName: contact.firstName,
          lastName: contact.lastName,
          vehicleYear: contact.vehicleYear,
          vehicleMake: contact.vehicleMake,
          vehicleModel: contact.vehicleModel,
          serviceInterest: contact.serviceInterest,
          businessName,
        }) : "",
        content: mergedContent,
        status: randomStatus,
      },
    });

    // Activity log
    await prisma.activityLog.create({
      data: {
        contactId: contact.id,
        type: "follow_up_sent",
        message: `${step.channel} sent to ${contact.firstName} ${contact.lastName}: Step ${stepIndex + 1}${loopCount > 0 ? ` (Loop ${loopCount})` : ""}`,
      },
    });

    // Update contact last contacted date
    await prisma.contact.update({
      where: { id: contact.id },
      data: {
        lastContactedDate: now,
        status: contact.status === "New" ? "Contacted" : contact.status,
      },
    });

    // Advance to next step
    const nextStepIndex = stepIndex + 1;
    let nextDueDate: Date;

    if (nextStepIndex < steps.length) {
      nextDueDate = new Date(now);
      nextDueDate.setDate(nextDueDate.getDate() + (steps[nextStepIndex].delayDays - step.delayDays));
    } else {
      // Loop: wait 30 days
      nextDueDate = new Date(now);
      nextDueDate.setDate(nextDueDate.getDate() + 30);
    }

    await prisma.sequenceEnrollment.update({
      where: { id: enrollment.id },
      data: {
        currentStepOrder: nextStepIndex,
        lastProcessedAt: now,
        nextDueDate: nextDueDate,
        loopCount: nextStepIndex >= steps.length ? loopCount + 1 : loopCount,
      },
    });

    processed++;
  }

  return NextResponse.json({
    processed,
    total: dueEnrollments.length,
    message: `Processed ${processed} of ${dueEnrollments.length} due messages`,
  });
}
