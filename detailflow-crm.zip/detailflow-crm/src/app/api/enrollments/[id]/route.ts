import { prisma } from "@/lib/db";
import { NextRequest, NextResponse } from "next/server";

export async function PATCH(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;
  const body = await req.json();

  const enrollment = await prisma.sequenceEnrollment.findUnique({
    where: { id },
    include: { sequence: { include: { steps: { orderBy: { order: "asc" } } } } },
  });

  if (!enrollment) return NextResponse.json({ error: "Not found" }, { status: 404 });

  const updateData: Record<string, unknown> = {};

  if (body.action === "pause") {
    updateData.status = "Paused";
  } else if (body.action === "resume") {
    updateData.status = "Active";
    updateData.nextDueDate = new Date();
  } else if (body.action === "restart") {
    updateData.status = "Active";
    updateData.currentStepOrder = 0;
    updateData.loopCount = 0;
    updateData.nextDueDate = new Date();
    const firstStep = enrollment.sequence.steps[0];
    if (firstStep) {
      const d = new Date();
      d.setDate(d.getDate() + firstStep.delayDays);
      updateData.nextDueDate = d;
    }
  } else if (body.action === "skip") {
    const nextOrder = enrollment.currentStepOrder + 1;
    updateData.currentStepOrder = nextOrder;
    if (nextOrder < enrollment.sequence.steps.length) {
      const nextStep = enrollment.sequence.steps[nextOrder];
      const d = new Date();
      d.setDate(d.getDate() + 1); // Skip means due tomorrow
      updateData.nextDueDate = d;
    } else {
      const d = new Date();
      d.setDate(d.getDate() + 30);
      updateData.nextDueDate = d;
    }
  } else if (body.action === "mark_sent") {
    // Advance to next step as if the current one was sent
    const nextOrder = enrollment.currentStepOrder + 1;
    updateData.currentStepOrder = nextOrder;
    updateData.lastProcessedAt = new Date();
    if (nextOrder < enrollment.sequence.steps.length) {
      const nextStep = enrollment.sequence.steps[nextOrder];
      const currentStep = enrollment.sequence.steps[enrollment.currentStepOrder];
      const d = new Date();
      d.setDate(d.getDate() + (nextStep.delayDays - (currentStep?.delayDays || 0)));
      updateData.nextDueDate = d;
    } else {
      const d = new Date();
      d.setDate(d.getDate() + 30);
      updateData.nextDueDate = d;
    }
  } else if (body.status) {
    updateData.status = body.status;
  }

  const updated = await prisma.sequenceEnrollment.update({
    where: { id },
    data: updateData,
  });

  return NextResponse.json(updated);
}
