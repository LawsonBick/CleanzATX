import { prisma } from "@/lib/db";
import { NextRequest, NextResponse } from "next/server";

export async function GET() {
  let profile = await prisma.businessProfile.findFirst();
  if (!profile) {
    profile = await prisma.businessProfile.create({
      data: { name: "Texas Auto Club Mobile Detailing" },
    });
  }
  return NextResponse.json(profile);
}

export async function PATCH(req: NextRequest) {
  const body = await req.json();
  let profile = await prisma.businessProfile.findFirst();

  if (!profile) {
    profile = await prisma.businessProfile.create({
      data: { name: body.name || "My Business", ...body },
    });
  } else {
    profile = await prisma.businessProfile.update({
      where: { id: profile.id },
      data: body,
    });
  }

  return NextResponse.json(profile);
}
