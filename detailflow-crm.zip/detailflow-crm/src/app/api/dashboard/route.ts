import { prisma } from "@/lib/db";
import { NextResponse } from "next/server";

export async function GET() {
  const [totalLeads, totalCustomers, allContacts, recentActivity, dueToday, totalRevenue] =
    await Promise.all([
      prisma.contact.count({ where: { type: "Lead" } }),
      prisma.contact.count({ where: { type: "Customer" } }),
      prisma.contact.count(),
      prisma.activityLog.findMany({
        orderBy: { createdAt: "desc" },
        take: 20,
        include: { contact: true },
      }),
      prisma.sequenceEnrollment.findMany({
        where: {
          status: "Active",
          nextDueDate: { lte: new Date() },
        },
        include: {
          contact: true,
          sequence: { include: { steps: { orderBy: { order: "asc" } } } },
        },
      }),
      prisma.job.aggregate({ _sum: { price: true } }),
    ]);

  const conversionRate =
    allContacts > 0 ? ((totalCustomers / allContacts) * 100).toFixed(1) : "0";

  return NextResponse.json({
    totalLeads,
    totalCustomers,
    conversionRate,
    totalRevenue: totalRevenue._sum.price || 0,
    recentActivity,
    dueToday,
  });
}
