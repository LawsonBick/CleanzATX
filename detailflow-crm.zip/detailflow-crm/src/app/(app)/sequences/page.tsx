"use client";

import { useEffect, useState, useCallback } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Zap,
  Plus,
  Trash2,
  GripVertical,
  MessageSquare,
  Mail,
  Eye,
  RefreshCw,
} from "lucide-react";
import { toast } from "sonner";
import { mergeTags } from "@/lib/merge-tags";

interface SequenceStep {
  id: string;
  order: number;
  delayDays: number;
  channel: string;
  subject: string;
  template: string;
}

interface Sequence {
  id: string;
  name: string;
  isDefault: boolean;
  steps: SequenceStep[];
  _count: { enrollments: number };
}

const mergeTagsList = [
  "[FirstName]",
  "[LastName]",
  "[BusinessName]",
  "[VehicleYear]",
  "[VehicleMake]",
  "[VehicleModel]",
  "[ServiceInterest]",
];

export default function SequencesPage() {
  const [sequences, setSequences] = useState<Sequence[]>([]);
  const [selected, setSelected] = useState<Sequence | null>(null);
  const [editingStep, setEditingStep] = useState<SequenceStep | null>(null);
  const [previewOpen, setPreviewOpen] = useState(false);
  const [previewContent, setPreviewContent] = useState("");
  const [addStepOpen, setAddStepOpen] = useState(false);
  const [loading, setLoading] = useState(true);

  const fetchSequences = useCallback(async () => {
    setLoading(true);
    const res = await fetch("/api/sequences");
    const data = await res.json();
    setSequences(data);
    setLoading(false);
  }, []);

  useEffect(() => {
    fetchSequences();
  }, [fetchSequences]);

  function openPreview(step: SequenceStep) {
    const merged = mergeTags(step.template, {
      firstName: "John",
      lastName: "Smith",
      vehicleYear: "2024",
      vehicleMake: "Tesla",
      vehicleModel: "Model 3",
      serviceInterest: "Full Detail",
      businessName: "Texas Auto Club Mobile Detailing",
    });
    setPreviewContent(merged);
    setPreviewOpen(true);
  }

  async function addStep(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    if (!selected) return;
    const form = new FormData(e.currentTarget);
    await fetch(`/api/sequences/${selected.id}/steps`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        delayDays: parseInt(form.get("delayDays") as string),
        channel: form.get("channel"),
        subject: form.get("subject") || "",
        template: form.get("template"),
      }),
    });
    toast.success("Step added");
    setAddStepOpen(false);
    const res = await fetch(`/api/sequences/${selected.id}`);
    const updated = await res.json();
    setSelected(updated);
    fetchSequences();
  }

  async function deleteStep(stepId: string) {
    await fetch(`/api/sequences/steps/${stepId}`, { method: "DELETE" });
    toast.success("Step deleted");
    if (selected) {
      const res = await fetch(`/api/sequences/${selected.id}`);
      setSelected(await res.json());
    }
    fetchSequences();
  }

  async function saveStep(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    if (!selected || !editingStep) return;
    const form = new FormData(e.currentTarget);
    const updatedSteps = selected.steps.map((s) =>
      s.id === editingStep.id
        ? {
            ...s,
            delayDays: parseInt(form.get("delayDays") as string),
            channel: form.get("channel") as string,
            subject: (form.get("subject") as string) || "",
            template: form.get("template") as string,
          }
        : s
    );

    await fetch(`/api/sequences/${selected.id}/steps`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ steps: updatedSteps }),
    });
    toast.success("Step updated");
    setEditingStep(null);
    const res = await fetch(`/api/sequences/${selected.id}`);
    setSelected(await res.json());
    fetchSequences();
  }

  if (loading) {
    return (
      <div className="flex h-64 items-center justify-center">
        <RefreshCw className="h-6 w-6 animate-spin text-gray-400" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Nurture Sequences</h1>
        <p className="text-muted-foreground">Build and manage your automated follow-up sequences</p>
      </div>

      {!selected ? (
        <div className="grid gap-4 md:grid-cols-2">
          {sequences.map((seq) => (
            <Card
              key={seq.id}
              className="cursor-pointer transition-shadow hover:shadow-md"
              onClick={() => setSelected(seq)}
            >
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  <span className="flex items-center gap-2">
                    <Zap className="h-5 w-5 text-purple-600" />
                    {seq.name}
                  </span>
                  {seq.isDefault && <Badge>Default</Badge>}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex gap-4 text-sm text-muted-foreground">
                  <span>{seq.steps.length} steps</span>
                  <span>{seq._count.enrollments} enrolled</span>
                </div>
              </CardContent>
            </Card>
          ))}
          {sequences.length === 0 && (
            <Card>
              <CardContent className="py-12 text-center">
                <p className="text-lg font-medium">No sequences yet</p>
                <p className="text-muted-foreground">Run the seed to create the default sequence</p>
              </CardContent>
            </Card>
          )}
        </div>
      ) : (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <Button variant="ghost" onClick={() => setSelected(null)} className="mb-2">
                &larr; Back to Sequences
              </Button>
              <h2 className="text-xl font-bold flex items-center gap-2">
                <Zap className="h-5 w-5 text-purple-600" />
                {selected.name}
                {selected.isDefault && <Badge className="ml-2">Default</Badge>}
              </h2>
            </div>
            <Button onClick={() => setAddStepOpen(true)} className="bg-purple-600 hover:bg-purple-700">
              <Plus className="mr-2 h-4 w-4" />
              Add Step
            </Button>
          </div>

          {/* Merge tags reference */}
          <Card>
            <CardContent className="py-3">
              <p className="text-xs font-medium text-muted-foreground mb-1">Available Merge Tags:</p>
              <div className="flex flex-wrap gap-2">
                {mergeTagsList.map((tag) => (
                  <Badge key={tag} variant="outline" className="text-xs font-mono">
                    {tag}
                  </Badge>
                ))}
              </div>
            </CardContent>
          </Card>

          <div className="space-y-3">
            {selected.steps.map((step, i) => (
              <Card key={step.id}>
                <CardContent className="flex items-start gap-4 py-4">
                  <div className="flex flex-col items-center gap-1 pt-1 text-muted-foreground">
                    <GripVertical className="h-4 w-4" />
                    <span className="text-xs font-bold">{i + 1}</span>
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <Badge variant={step.channel === "SMS" ? "default" : "secondary"}>
                        {step.channel === "SMS" ? (
                          <MessageSquare className="mr-1 h-3 w-3" />
                        ) : (
                          <Mail className="mr-1 h-3 w-3" />
                        )}
                        {step.channel}
                      </Badge>
                      <span className="text-sm text-muted-foreground">
                        Day {step.delayDays}
                      </span>
                      {step.subject && (
                        <span className="text-sm font-medium truncate">
                          Subject: {step.subject}
                        </span>
                      )}
                    </div>
                    <p className="text-sm text-muted-foreground line-clamp-2">{step.template}</p>
                  </div>
                  <div className="flex gap-1">
                    <Button size="icon" variant="ghost" onClick={() => openPreview(step)}>
                      <Eye className="h-4 w-4" />
                    </Button>
                    <Button size="icon" variant="ghost" onClick={() => setEditingStep(step)}>
                      <Zap className="h-4 w-4" />
                    </Button>
                    <Button size="icon" variant="ghost" onClick={() => deleteStep(step.id)}>
                      <Trash2 className="h-4 w-4 text-red-500" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      )}

      {/* Preview Dialog */}
      <Dialog open={previewOpen} onOpenChange={setPreviewOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Message Preview</DialogTitle>
          </DialogHeader>
          <div className="rounded-lg bg-gray-50 p-4">
            <p className="whitespace-pre-wrap text-sm">{previewContent}</p>
          </div>
          <p className="text-xs text-muted-foreground">
            Preview uses sample data: John Smith, 2024 Tesla Model 3, Full Detail
          </p>
        </DialogContent>
      </Dialog>

      {/* Add Step Dialog */}
      <Dialog open={addStepOpen} onOpenChange={setAddStepOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Add Sequence Step</DialogTitle>
          </DialogHeader>
          <form onSubmit={addStep} className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label>Delay (days)</Label>
                <Input name="delayDays" type="number" min="0" required defaultValue="1" />
              </div>
              <div>
                <Label>Channel</Label>
                <Select name="channel" defaultValue="SMS">
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="SMS">SMS</SelectItem>
                    <SelectItem value="Email">Email</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div>
              <Label>Subject (Email only)</Label>
              <Input name="subject" placeholder="Email subject line" />
            </div>
            <div>
              <Label>Message Template</Label>
              <Textarea name="template" rows={4} required placeholder="Hey [FirstName]! ..." />
            </div>
            <Button type="submit" className="w-full bg-purple-600 hover:bg-purple-700">Add Step</Button>
          </form>
        </DialogContent>
      </Dialog>

      {/* Edit Step Dialog */}
      <Dialog open={!!editingStep} onOpenChange={() => setEditingStep(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Edit Step</DialogTitle>
          </DialogHeader>
          {editingStep && (
            <form onSubmit={saveStep} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label>Delay (days)</Label>
                  <Input name="delayDays" type="number" min="0" required defaultValue={editingStep.delayDays} />
                </div>
                <div>
                  <Label>Channel</Label>
                  <Select name="channel" defaultValue={editingStep.channel}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="SMS">SMS</SelectItem>
                      <SelectItem value="Email">Email</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div>
                <Label>Subject</Label>
                <Input name="subject" defaultValue={editingStep.subject} />
              </div>
              <div>
                <Label>Message Template</Label>
                <Textarea name="template" rows={4} required defaultValue={editingStep.template} />
              </div>
              <Button type="submit" className="w-full bg-purple-600 hover:bg-purple-700">Save Changes</Button>
            </form>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
