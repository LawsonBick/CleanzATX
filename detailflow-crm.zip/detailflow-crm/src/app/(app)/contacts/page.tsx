"use client";

import { useEffect, useState, useCallback } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Search, Phone, Mail, Car, RefreshCw, DollarSign } from "lucide-react";
import { toast } from "sonner";
import { format } from "date-fns";

interface Contact {
  id: string;
  firstName: string;
  lastName: string;
  phone: string;
  email: string;
  source: string;
  vehicleYear: string;
  vehicleMake: string;
  vehicleModel: string;
  vehicleColor: string;
  serviceInterest: string;
  notes: string;
  status: string;
  type: string;
  totalLifetimeValue: number;
  nextFollowUpDate: string | null;
  lastContactedDate: string | null;
  createdAt: string;
  jobs: Array<{ id: string; service: string; price: number; date: string; notes: string }>;
  sequenceEnrollments: Array<{
    id: string;
    status: string;
    currentStepOrder: number;
    sequence: { name: string };
  }>;
}

const statuses = ["New", "Contacted", "Nurturing", "Quoted", "Converted", "Opted Out", "Lost"];
const statusColors: Record<string, string> = {
  New: "bg-blue-100 text-blue-800",
  Contacted: "bg-yellow-100 text-yellow-800",
  Nurturing: "bg-purple-100 text-purple-800",
  Quoted: "bg-orange-100 text-orange-800",
  Converted: "bg-green-100 text-green-800",
  "Opted Out": "bg-gray-100 text-gray-800",
  Lost: "bg-red-100 text-red-800",
};

export default function ContactsPage() {
  const [contacts, setContacts] = useState<Contact[]>([]);
  const [search, setSearch] = useState("");
  const [typeFilter, setTypeFilter] = useState("all");
  const [selected, setSelected] = useState<Contact | null>(null);
  const [loading, setLoading] = useState(true);
  const [jobDialogOpen, setJobDialogOpen] = useState(false);

  const fetchContacts = useCallback(async () => {
    setLoading(true);
    const params = new URLSearchParams();
    if (search) params.set("search", search);
    if (typeFilter !== "all") params.set("type", typeFilter);
    const res = await fetch(`/api/contacts?${params}`);
    setContacts(await res.json());
    setLoading(false);
  }, [search, typeFilter]);

  useEffect(() => {
    fetchContacts();
    const handler = () => fetchContacts();
    window.addEventListener("lead-added", handler);
    return () => window.removeEventListener("lead-added", handler);
  }, [fetchContacts]);

  async function updateStatus(id: string, status: string) {
    await fetch(`/api/contacts/${id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ status }),
    });
    toast.success(`Status updated to ${status}`);
    fetchContacts();
    if (selected?.id === id) {
      const res = await fetch(`/api/contacts/${id}`);
      setSelected(await res.json());
    }
  }

  async function addJob(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    if (!selected) return;
    const form = new FormData(e.currentTarget);
    await fetch(`/api/contacts/${selected.id}/jobs`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        service: form.get("service"),
        price: form.get("price"),
        date: form.get("date"),
        notes: form.get("jobNotes") || "",
      }),
    });
    toast.success("Job added");
    setJobDialogOpen(false);
    const res = await fetch(`/api/contacts/${selected.id}`);
    setSelected(await res.json());
    fetchContacts();
  }

  const filtered = contacts;

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Contacts</h1>
        <p className="text-muted-foreground">Manage your leads and customers</p>
      </div>

      <div className="flex flex-col gap-4 sm:flex-row">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            placeholder="Search contacts..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-10"
          />
        </div>
        <Select value={typeFilter} onValueChange={setTypeFilter}>
          <SelectTrigger className="w-40">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Types</SelectItem>
            <SelectItem value="Lead">Leads</SelectItem>
            <SelectItem value="Customer">Customers</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {loading ? (
        <div className="flex h-32 items-center justify-center">
          <RefreshCw className="h-6 w-6 animate-spin text-gray-400" />
        </div>
      ) : filtered.length === 0 ? (
        <Card>
          <CardContent className="py-12 text-center">
            <p className="text-lg font-medium">No contacts yet</p>
            <p className="text-muted-foreground">Click the + button to add your first lead</p>
          </CardContent>
        </Card>
      ) : (
        <Card>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Name</TableHead>
                  <TableHead>Contact</TableHead>
                  <TableHead>Vehicle</TableHead>
                  <TableHead>Service</TableHead>
                  <TableHead>Source</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Type</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filtered.map((c) => (
                  <TableRow
                    key={c.id}
                    className="cursor-pointer hover:bg-gray-50"
                    onClick={() => setSelected(c)}
                  >
                    <TableCell className="font-medium">{c.firstName} {c.lastName}</TableCell>
                    <TableCell>
                      <div className="flex flex-col gap-1">
                        <span className="flex items-center gap-1 text-xs">
                          <Phone className="h-3 w-3" />{c.phone}
                        </span>
                        {c.email && (
                          <span className="flex items-center gap-1 text-xs">
                            <Mail className="h-3 w-3" />{c.email}
                          </span>
                        )}
                      </div>
                    </TableCell>
                    <TableCell>
                      <span className="flex items-center gap-1 text-sm">
                        <Car className="h-3 w-3" />
                        {c.vehicleYear} {c.vehicleMake} {c.vehicleModel}
                      </span>
                    </TableCell>
                    <TableCell>{c.serviceInterest}</TableCell>
                    <TableCell>{c.source}</TableCell>
                    <TableCell>
                      <Badge className={statusColors[c.status] || ""}>{c.status}</Badge>
                    </TableCell>
                    <TableCell>
                      <Badge variant={c.type === "Customer" ? "default" : "outline"}>{c.type}</Badge>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </Card>
      )}

      {/* Contact Detail Dialog */}
      <Dialog open={!!selected} onOpenChange={() => setSelected(null)}>
        <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-2xl">
          {selected && (
            <>
              <DialogHeader>
                <DialogTitle className="flex items-center gap-2">
                  {selected.firstName} {selected.lastName}
                  <Badge className={statusColors[selected.status] || ""}>{selected.status}</Badge>
                  <Badge variant={selected.type === "Customer" ? "default" : "outline"}>{selected.type}</Badge>
                </DialogTitle>
              </DialogHeader>

              <Tabs defaultValue="info" className="mt-4">
                <TabsList>
                  <TabsTrigger value="info">Info</TabsTrigger>
                  <TabsTrigger value="jobs">Jobs ({selected.jobs?.length || 0})</TabsTrigger>
                  <TabsTrigger value="sequence">Sequence</TabsTrigger>
                </TabsList>

                <TabsContent value="info" className="space-y-4">
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div><span className="text-muted-foreground">Phone:</span> {selected.phone}</div>
                    <div><span className="text-muted-foreground">Email:</span> {selected.email || "—"}</div>
                    <div><span className="text-muted-foreground">Vehicle:</span> {selected.vehicleYear} {selected.vehicleMake} {selected.vehicleModel} {selected.vehicleColor}</div>
                    <div><span className="text-muted-foreground">Service:</span> {selected.serviceInterest}</div>
                    <div><span className="text-muted-foreground">Source:</span> {selected.source}</div>
                    <div><span className="text-muted-foreground">Created:</span> {format(new Date(selected.createdAt), "MMM d, yyyy")}</div>
                    {selected.lastContactedDate && (
                      <div><span className="text-muted-foreground">Last Contacted:</span> {format(new Date(selected.lastContactedDate), "MMM d, yyyy")}</div>
                    )}
                    {selected.type === "Customer" && (
                      <div className="flex items-center gap-1">
                        <DollarSign className="h-4 w-4 text-green-600" />
                        <span className="font-medium">Lifetime Value: ${selected.totalLifetimeValue.toLocaleString()}</span>
                      </div>
                    )}
                  </div>
                  {selected.notes && (
                    <div>
                      <p className="text-sm text-muted-foreground">Notes:</p>
                      <p className="text-sm">{selected.notes}</p>
                    </div>
                  )}
                  <div>
                    <Label>Update Status</Label>
                    <Select value={selected.status} onValueChange={(v) => updateStatus(selected.id, v)}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {statuses.map((s) => (
                          <SelectItem key={s} value={s}>{s}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </TabsContent>

                <TabsContent value="jobs" className="space-y-4">
                  <Button onClick={() => setJobDialogOpen(true)} size="sm" className="bg-purple-600 hover:bg-purple-700">
                    Add Job
                  </Button>
                  {selected.jobs?.length === 0 ? (
                    <p className="text-sm text-muted-foreground">No jobs recorded yet</p>
                  ) : (
                    <div className="space-y-2">
                      {selected.jobs?.map((job) => (
                        <div key={job.id} className="flex items-center justify-between rounded-lg border p-3">
                          <div>
                            <p className="font-medium">{job.service}</p>
                            <p className="text-sm text-muted-foreground">{format(new Date(job.date), "MMM d, yyyy")}</p>
                            {job.notes && <p className="text-sm">{job.notes}</p>}
                          </div>
                          <span className="font-bold text-green-600">${job.price}</span>
                        </div>
                      ))}
                    </div>
                  )}
                </TabsContent>

                <TabsContent value="sequence" className="space-y-4">
                  {selected.sequenceEnrollments?.length === 0 ? (
                    <p className="text-sm text-muted-foreground">Not enrolled in any sequence</p>
                  ) : (
                    selected.sequenceEnrollments?.map((e) => (
                      <div key={e.id} className="rounded-lg border p-3">
                        <p className="font-medium">{e.sequence.name}</p>
                        <p className="text-sm text-muted-foreground">
                          Step {e.currentStepOrder + 1} | Status: {e.status}
                        </p>
                      </div>
                    ))
                  )}
                </TabsContent>
              </Tabs>
            </>
          )}
        </DialogContent>
      </Dialog>

      {/* Add Job Dialog */}
      <Dialog open={jobDialogOpen} onOpenChange={setJobDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Add Job</DialogTitle>
          </DialogHeader>
          <form onSubmit={addJob} className="space-y-4">
            <div>
              <Label>Service</Label>
              <Select name="service" required>
                <SelectTrigger>
                  <SelectValue placeholder="Select service" />
                </SelectTrigger>
                <SelectContent>
                  {["Full Detail", "Interior Only", "Exterior Only", "Ceramic Coating", "Paint Correction"].map((s) => (
                    <SelectItem key={s} value={s}>{s}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>Price</Label>
              <Input name="price" type="number" step="0.01" required />
            </div>
            <div>
              <Label>Date</Label>
              <Input name="date" type="date" required defaultValue={new Date().toISOString().split("T")[0]} />
            </div>
            <div>
              <Label>Notes</Label>
              <Textarea name="jobNotes" rows={2} />
            </div>
            <Button type="submit" className="w-full bg-purple-600 hover:bg-purple-700">Save Job</Button>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
