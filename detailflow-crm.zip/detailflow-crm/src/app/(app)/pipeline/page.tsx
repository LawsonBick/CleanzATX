"use client";

import { useEffect, useState, useCallback } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { RefreshCw, Car } from "lucide-react";
import { toast } from "sonner";
import { formatDistanceToNow } from "date-fns";

interface Contact {
  id: string;
  firstName: string;
  lastName: string;
  vehicleMake: string;
  vehicleModel: string;
  vehicleYear: string;
  source: string;
  status: string;
  serviceInterest: string;
  createdAt: string;
  nextFollowUpDate: string | null;
  sequenceEnrollments: Array<{
    nextDueDate: string | null;
    currentStepOrder: number;
    sequence: { steps: Array<{ channel: string }> };
  }>;
}

const columns = [
  { id: "New", label: "New Lead", color: "bg-blue-500" },
  { id: "Contacted", label: "Contacted", color: "bg-yellow-500" },
  { id: "Nurturing", label: "Nurturing", color: "bg-purple-500" },
  { id: "Quoted", label: "Quoted", color: "bg-orange-500" },
  { id: "Converted", label: "Converted", color: "bg-green-500" },
];

export default function PipelinePage() {
  const [contacts, setContacts] = useState<Contact[]>([]);
  const [loading, setLoading] = useState(true);
  const [dragging, setDragging] = useState<string | null>(null);

  const fetchData = useCallback(async () => {
    setLoading(true);
    const res = await fetch("/api/contacts");
    setContacts(await res.json());
    setLoading(false);
  }, []);

  useEffect(() => {
    fetchData();
    const handler = () => fetchData();
    window.addEventListener("lead-added", handler);
    return () => window.removeEventListener("lead-added", handler);
  }, [fetchData]);

  async function moveContact(contactId: string, newStatus: string) {
    await fetch(`/api/contacts/${contactId}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ status: newStatus }),
    });
    toast.success(`Moved to ${newStatus}`);
    fetchData();
  }

  function handleDragStart(e: React.DragEvent, contactId: string) {
    setDragging(contactId);
    e.dataTransfer.setData("text/plain", contactId);
  }

  function handleDrop(e: React.DragEvent, status: string) {
    e.preventDefault();
    const contactId = e.dataTransfer.getData("text/plain");
    if (contactId && contactId !== dragging) {
      moveContact(contactId, status);
    } else if (dragging) {
      moveContact(dragging, status);
    }
    setDragging(null);
  }

  function handleDragOver(e: React.DragEvent) {
    e.preventDefault();
  }

  if (loading) {
    return <div className="flex h-64 items-center justify-center"><RefreshCw className="h-6 w-6 animate-spin text-gray-400" /></div>;
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Pipeline</h1>
        <p className="text-muted-foreground">Drag and drop contacts between stages</p>
      </div>

      <div className="flex gap-4 overflow-x-auto pb-4">
        {columns.map((col) => {
          const colContacts = contacts.filter((c) => c.status === col.id);
          return (
            <div
              key={col.id}
              className="min-w-[280px] flex-1"
              onDragOver={handleDragOver}
              onDrop={(e) => handleDrop(e, col.id)}
            >
              <div className="mb-3 flex items-center gap-2">
                <div className={`h-3 w-3 rounded-full ${col.color}`} />
                <h3 className="font-semibold">{col.label}</h3>
                <Badge variant="outline" className="ml-auto">{colContacts.length}</Badge>
              </div>

              <div className="space-y-2 rounded-lg bg-gray-100 p-2 min-h-[200px]">
                {colContacts.map((contact) => {
                  const enrollment = contact.sequenceEnrollments?.[0];
                  const daysInStage = Math.floor(
                    (Date.now() - new Date(contact.createdAt).getTime()) / (1000 * 60 * 60 * 24)
                  );

                  return (
                    <Card
                      key={contact.id}
                      draggable
                      onDragStart={(e) => handleDragStart(e, contact.id)}
                      className="cursor-grab active:cursor-grabbing"
                    >
                      <CardContent className="p-3">
                        <div className="flex items-start justify-between">
                          <p className="font-medium text-sm">
                            {contact.firstName} {contact.lastName}
                          </p>
                          <Badge variant="outline" className="text-xs">{contact.source}</Badge>
                        </div>
                        <p className="mt-1 flex items-center gap-1 text-xs text-muted-foreground">
                          <Car className="h-3 w-3" />
                          {contact.vehicleYear} {contact.vehicleMake} {contact.vehicleModel}
                        </p>
                        <div className="mt-2 flex items-center justify-between text-xs">
                          <span className="text-muted-foreground">{daysInStage}d in stage</span>
                          {enrollment?.nextDueDate && (
                            <span className="text-purple-600">
                              Next: {formatDistanceToNow(new Date(enrollment.nextDueDate), { addSuffix: true })}
                            </span>
                          )}
                        </div>
                      </CardContent>
                    </Card>
                  );
                })}

                {colContacts.length === 0 && (
                  <div className="flex h-24 items-center justify-center rounded-lg border-2 border-dashed border-gray-300 text-sm text-muted-foreground">
                    Drop here
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
