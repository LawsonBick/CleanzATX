"use client";

import { useEffect, useState, useCallback } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Users,
  UserCheck,
  TrendingUp,
  DollarSign,
  Clock,
  Play,
  RefreshCw,
} from "lucide-react";
import { toast } from "sonner";
import { formatDistanceToNow } from "date-fns";

interface DashboardData {
  totalLeads: number;
  totalCustomers: number;
  conversionRate: string;
  totalRevenue: number;
  recentActivity: Array<{
    id: string;
    type: string;
    message: string;
    createdAt: string;
  }>;
  dueToday: Array<{
    id: string;
    contact: { id: string; firstName: string; lastName: string; vehicleMake: string };
    sequence: { name: string; steps: Array<{ channel: string; order: number }> };
    currentStepOrder: number;
  }>;
}

export default function DashboardPage() {
  const [data, setData] = useState<DashboardData | null>(null);
  const [processing, setProcessing] = useState(false);

  const fetchData = useCallback(async () => {
    const res = await fetch("/api/dashboard");
    setData(await res.json());
  }, []);

  useEffect(() => {
    fetchData();
    const handler = () => fetchData();
    window.addEventListener("lead-added", handler);
    return () => window.removeEventListener("lead-added", handler);
  }, [fetchData]);

  async function processQueue() {
    setProcessing(true);
    try {
      const res = await fetch("/api/process-queue", { method: "POST" });
      const result = await res.json();
      toast.success(result.message);
      fetchData();
    } catch {
      toast.error("Failed to process queue");
    } finally {
      setProcessing(false);
    }
  }

  if (!data) return <div className="flex h-64 items-center justify-center"><RefreshCw className="h-6 w-6 animate-spin text-gray-400" /></div>;

  const activityIcons: Record<string, string> = {
    lead_added: "bg-blue-100 text-blue-600",
    follow_up_sent: "bg-purple-100 text-purple-600",
    status_changed: "bg-yellow-100 text-yellow-600",
    converted: "bg-green-100 text-green-600",
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">Dashboard</h1>
          <p className="text-muted-foreground">Welcome to DetailFlow CRM</p>
        </div>
        <Button onClick={processQueue} disabled={processing} className="bg-purple-600 hover:bg-purple-700">
          <Play className="mr-2 h-4 w-4" />
          {processing ? "Processing..." : "Process Queue"}
        </Button>
      </div>

      {/* Stats */}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Total Leads</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{data.totalLeads}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Customers</CardTitle>
            <UserCheck className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{data.totalCustomers}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Conversion Rate</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{data.conversionRate}%</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Revenue</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">${data.totalRevenue.toLocaleString()}</div>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        {/* Due Today */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Clock className="h-5 w-5 text-purple-600" />
              Due Today ({data.dueToday.length})
            </CardTitle>
          </CardHeader>
          <CardContent>
            {data.dueToday.length === 0 ? (
              <p className="text-sm text-muted-foreground">No follow-ups due today. Hit &quot;Process Queue&quot; to check.</p>
            ) : (
              <div className="space-y-3">
                {data.dueToday.slice(0, 8).map((item) => {
                  const step = item.sequence.steps[item.currentStepOrder];
                  return (
                    <div key={item.id} className="flex items-center justify-between rounded-lg border p-3">
                      <div>
                        <p className="font-medium">{item.contact.firstName} {item.contact.lastName}</p>
                        <p className="text-sm text-muted-foreground">{item.contact.vehicleMake}</p>
                      </div>
                      {step && (
                        <Badge variant={step.channel === "SMS" ? "default" : "secondary"}>
                          {step.channel} - Step {item.currentStepOrder + 1}
                        </Badge>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Recent Activity */}
        <Card>
          <CardHeader>
            <CardTitle>Recent Activity</CardTitle>
          </CardHeader>
          <CardContent>
            {data.recentActivity.length === 0 ? (
              <p className="text-sm text-muted-foreground">No activity yet. Add your first lead to get started!</p>
            ) : (
              <div className="space-y-3">
                {data.recentActivity.slice(0, 10).map((activity) => (
                  <div key={activity.id} className="flex items-start gap-3">
                    <div className={`mt-0.5 rounded-full p-1.5 ${activityIcons[activity.type] || "bg-gray-100 text-gray-600"}`}>
                      <div className="h-2 w-2 rounded-full bg-current" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm">{activity.message}</p>
                      <p className="text-xs text-muted-foreground">
                        {formatDistanceToNow(new Date(activity.createdAt), { addSuffix: true })}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
