"use client";

import { useEffect, useState, useCallback, useMemo } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { CheckCircle, Pause, Play, SkipForward, RotateCcw, MoreHorizontal, RefreshCw, Clock } from "lucide-react";
import { toast } from "sonner";
import { format } from "date-fns";

interface Enrollment {
  id: string;
  currentStepOrder: number;
  status: string;
  nextDueDate: string | null;
  lastProcessedAt: string | null;
  loopCount: number;
  contact: {
    id: string;
    firstName: string;
    lastName: string;
    phone: string;
    vehicleMake: string;
    vehicleModel: string;
    status: string;
  };
  sequence: {
    name: string;
    steps: Array<{ order: number; channel: string; delayDays: number }>;
  };
}

export default function FollowUpsPage() {
  const [enrollments, setEnrollments] = useState<Enrollment[]>([]);
  const [loading, setLoading] = useState(true);
  const [processing, setProcessing] = useState(false);
  const [now] = useState(() => new Date());

  const fetchData = useCallback(async () => {
    try {
      const res = await fetch("/api/contacts?type=Lead");
      const contacts = await res.json();
      const allEnrollments: Enrollment[] = [];
      for (const c of contacts) {
        for (const e of c.sequenceEnrollments || []) {
          allEnrollments.push({ ...e, contact: c });
        }
      }
      allEnrollments.sort((a, b) => {
        if (!a.nextDueDate) return 1;
        if (!b.nextDueDate) return -1;
        return new Date(a.nextDueDate).getTime() - new Date(b.nextDueDate).getTime();
      });
      setEnrollments(allEnrollments);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  async function handleAction(id: string, action: string) {
    await fetch(`/api/enrollments/${id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action }),
    });
    toast.success(`Action "${action}" applied`);
    fetchData();
  }

  async function processQueue() {
    setProcessing(true);
    try {
      const res = await fetch("/api/process-queue", { method: "POST" });
      const result = await res.json();
      toast.success(result.message);
      fetchData();
    } catch {
      toast.error("Failed to process");
    } finally {
      setProcessing(false);
    }
  }

  const { dueToday, upcoming, paused } = useMemo(() => {
    const dueToday = enrollments.filter(
      (e) => e.status === "Active" && e.nextDueDate && new Date(e.nextDueDate) <= now
    );
    const upcoming = enrollments.filter(
      (e) => e.status === "Active" && e.nextDueDate && new Date(e.nextDueDate) > now
    );
    const paused = enrollments.filter((e) => e.status === "Paused");
    return { dueToday, upcoming, paused };
  }, [enrollments, now]);

  if (loading) {
    return <div className="flex h-64 items-center justify-center"><RefreshCw className="h-6 w-6 animate-spin text-gray-400" /></div>;
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">Follow-up Queue</h1>
          <p className="text-muted-foreground">Track and manage your nurture sequence progress</p>
        </div>
        <Button onClick={processQueue} disabled={processing} className="bg-purple-600 hover:bg-purple-700">
          <Play className="mr-2 h-4 w-4" />
          {processing ? "Processing..." : "Process Queue"}
        </Button>
      </div>

      {/* Due Today */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Clock className="h-5 w-5 text-red-500" />
            Due Today ({dueToday.length})
          </CardTitle>
        </CardHeader>
        <CardContent>
          {dueToday.length === 0 ? (
            <p className="text-sm text-muted-foreground">No follow-ups due right now</p>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Contact</TableHead>
                    <TableHead>Vehicle</TableHead>
                    <TableHead>Sequence</TableHead>
                    <TableHead>Step</TableHead>
                    <TableHead>Due</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {dueToday.map((e) => {
                    const step = e.sequence?.steps?.[e.currentStepOrder];
                    return (
                      <TableRow key={e.id}>
                        <TableCell className="font-medium">{e.contact.firstName} {e.contact.lastName}</TableCell>
                        <TableCell>{e.contact.vehicleMake} {e.contact.vehicleModel}</TableCell>
                        <TableCell>{e.sequence?.name || "—"}</TableCell>
                        <TableCell>
                          <Badge variant={step?.channel === "SMS" ? "default" : "secondary"}>
                            {step?.channel || "?"} - Step {e.currentStepOrder + 1}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-red-600 font-medium">
                          {e.nextDueDate ? format(new Date(e.nextDueDate), "MMM d, h:mm a") : "—"}
                        </TableCell>
                        <TableCell>
                          <div className="flex gap-1">
                            <Button size="sm" variant="outline" onClick={() => handleAction(e.id, "mark_sent")}>
                              <CheckCircle className="mr-1 h-3 w-3" />
                              Sent
                            </Button>
                            <DropdownMenu>
                              <DropdownMenuTrigger asChild>
                                <Button size="icon" variant="ghost"><MoreHorizontal className="h-4 w-4" /></Button>
                              </DropdownMenuTrigger>
                              <DropdownMenuContent>
                                <DropdownMenuItem onClick={() => handleAction(e.id, "skip")}>
                                  <SkipForward className="mr-2 h-4 w-4" />Skip Step
                                </DropdownMenuItem>
                                <DropdownMenuItem onClick={() => handleAction(e.id, "pause")}>
                                  <Pause className="mr-2 h-4 w-4" />Pause
                                </DropdownMenuItem>
                                <DropdownMenuItem onClick={() => handleAction(e.id, "restart")}>
                                  <RotateCcw className="mr-2 h-4 w-4" />Restart
                                </DropdownMenuItem>
                              </DropdownMenuContent>
                            </DropdownMenu>
                          </div>
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Upcoming */}
      <Card>
        <CardHeader>
          <CardTitle>Upcoming ({upcoming.length})</CardTitle>
        </CardHeader>
        <CardContent>
          {upcoming.length === 0 ? (
            <p className="text-sm text-muted-foreground">No upcoming follow-ups</p>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Contact</TableHead>
                    <TableHead>Sequence</TableHead>
                    <TableHead>Step</TableHead>
                    <TableHead>Due Date</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {upcoming.slice(0, 20).map((e) => {
                    const step = e.sequence?.steps?.[e.currentStepOrder];
                    return (
                      <TableRow key={e.id}>
                        <TableCell className="font-medium">{e.contact.firstName} {e.contact.lastName}</TableCell>
                        <TableCell>{e.sequence?.name || "—"}</TableCell>
                        <TableCell>
                          <Badge variant={step?.channel === "SMS" ? "default" : "secondary"}>
                            {step?.channel || "?"} - Step {e.currentStepOrder + 1}
                            {e.loopCount > 0 && ` (Loop ${e.loopCount})`}
                          </Badge>
                        </TableCell>
                        <TableCell>{e.nextDueDate ? format(new Date(e.nextDueDate), "MMM d, yyyy") : "—"}</TableCell>
                        <TableCell>
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button size="icon" variant="ghost"><MoreHorizontal className="h-4 w-4" /></Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent>
                              <DropdownMenuItem onClick={() => handleAction(e.id, "skip")}>
                                <SkipForward className="mr-2 h-4 w-4" />Skip
                              </DropdownMenuItem>
                              <DropdownMenuItem onClick={() => handleAction(e.id, "pause")}>
                                <Pause className="mr-2 h-4 w-4" />Pause
                              </DropdownMenuItem>
                              <DropdownMenuItem onClick={() => handleAction(e.id, "restart")}>
                                <RotateCcw className="mr-2 h-4 w-4" />Restart
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Paused */}
      {paused.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>Paused ({paused.length})</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Contact</TableHead>
                    <TableHead>Sequence</TableHead>
                    <TableHead>Step</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {paused.map((e) => (
                    <TableRow key={e.id}>
                      <TableCell className="font-medium">{e.contact.firstName} {e.contact.lastName}</TableCell>
                      <TableCell>{e.sequence?.name || "—"}</TableCell>
                      <TableCell>Step {e.currentStepOrder + 1}</TableCell>
                      <TableCell>
                        <Button size="sm" variant="outline" onClick={() => handleAction(e.id, "resume")}>
                          <Play className="mr-1 h-3 w-3" />Resume
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
