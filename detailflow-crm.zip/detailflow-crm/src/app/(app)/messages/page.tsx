"use client";

import { useEffect, useState, useCallback } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Search, MessageSquare, Mail, RefreshCw } from "lucide-react";
import { format } from "date-fns";

interface Message {
  id: string;
  channel: string;
  subject: string;
  content: string;
  status: string;
  sentAt: string;
  contact: {
    id: string;
    firstName: string;
    lastName: string;
    phone: string;
  };
}

const statusColors: Record<string, string> = {
  Sent: "bg-blue-100 text-blue-800",
  Opened: "bg-green-100 text-green-800",
  Replied: "bg-purple-100 text-purple-800",
};

export default function MessagesPage() {
  const [messages, setMessages] = useState<Message[]>([]);
  const [search, setSearch] = useState("");
  const [channel, setChannel] = useState("all");
  const [selected, setSelected] = useState<Message | null>(null);
  const [loading, setLoading] = useState(true);

  const fetchData = useCallback(async () => {
    setLoading(true);
    const params = new URLSearchParams();
    if (search) params.set("search", search);
    if (channel !== "all") params.set("channel", channel);
    const res = await fetch(`/api/messages?${params}`);
    setMessages(await res.json());
    setLoading(false);
  }, [search, channel]);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  if (loading) {
    return <div className="flex h-64 items-center justify-center"><RefreshCw className="h-6 w-6 animate-spin text-gray-400" /></div>;
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Message Log</h1>
        <p className="text-muted-foreground">History of all simulated SMS and email messages</p>
      </div>

      <div className="flex flex-col gap-4 sm:flex-row">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            placeholder="Search messages..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-10"
          />
        </div>
        <Select value={channel} onValueChange={setChannel}>
          <SelectTrigger className="w-40">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Channels</SelectItem>
            <SelectItem value="SMS">SMS</SelectItem>
            <SelectItem value="Email">Email</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {messages.length === 0 ? (
        <Card>
          <CardContent className="py-12 text-center">
            <p className="text-lg font-medium">No messages yet</p>
            <p className="text-muted-foreground">Messages will appear here after processing the queue</p>
          </CardContent>
        </Card>
      ) : (
        <Card>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Channel</TableHead>
                  <TableHead>Contact</TableHead>
                  <TableHead>Content</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Sent At</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {messages.map((msg) => (
                  <TableRow
                    key={msg.id}
                    className="cursor-pointer hover:bg-gray-50"
                    onClick={() => setSelected(msg)}
                  >
                    <TableCell>
                      <Badge variant={msg.channel === "SMS" ? "default" : "secondary"}>
                        {msg.channel === "SMS" ? (
                          <MessageSquare className="mr-1 h-3 w-3" />
                        ) : (
                          <Mail className="mr-1 h-3 w-3" />
                        )}
                        {msg.channel}
                      </Badge>
                    </TableCell>
                    <TableCell className="font-medium">
                      {msg.contact.firstName} {msg.contact.lastName}
                    </TableCell>
                    <TableCell className="max-w-xs truncate">{msg.content}</TableCell>
                    <TableCell>
                      <Badge className={statusColors[msg.status] || ""}>{msg.status}</Badge>
                    </TableCell>
                    <TableCell>{format(new Date(msg.sentAt), "MMM d, h:mm a")}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </Card>
      )}

      <Dialog open={!!selected} onOpenChange={() => setSelected(null)}>
        <DialogContent>
          {selected && (
            <>
              <DialogHeader>
                <DialogTitle className="flex items-center gap-2">
                  <Badge variant={selected.channel === "SMS" ? "default" : "secondary"}>
                    {selected.channel}
                  </Badge>
                  to {selected.contact.firstName} {selected.contact.lastName}
                </DialogTitle>
              </DialogHeader>
              <div className="space-y-3">
                {selected.subject && (
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Subject</p>
                    <p>{selected.subject}</p>
                  </div>
                )}
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Message</p>
                  <div className="rounded-lg bg-gray-50 p-4">
                    <p className="whitespace-pre-wrap text-sm">{selected.content}</p>
                  </div>
                </div>
                <div className="flex gap-4 text-sm text-muted-foreground">
                  <span>Status: <Badge className={statusColors[selected.status] || ""}>{selected.status}</Badge></span>
                  <span>Sent: {format(new Date(selected.sentAt), "MMM d, yyyy h:mm a")}</span>
                </div>
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
