"use client";

import { useEffect, useState, useCallback } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { Settings, Save, RefreshCw } from "lucide-react";
import { toast } from "sonner";

interface BusinessProfile {
  id: string;
  name: string;
  phone: string;
  email: string;
  businessHours: string;
  optOutKeywords: string;
}

export default function SettingsPage() {
  const [profile, setProfile] = useState<BusinessProfile | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  const fetchProfile = useCallback(async () => {
    setLoading(true);
    const res = await fetch("/api/settings");
    setProfile(await res.json());
    setLoading(false);
  }, []);

  useEffect(() => {
    fetchProfile();
  }, [fetchProfile]);

  async function handleSave(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setSaving(true);
    const form = new FormData(e.currentTarget);

    const hours = JSON.stringify({
      start: form.get("startHour"),
      end: form.get("endHour"),
      days: [1, 2, 3, 4, 5, 6],
    });

    await fetch("/api/settings", {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        name: form.get("name"),
        phone: form.get("phone"),
        email: form.get("email"),
        businessHours: hours,
        optOutKeywords: form.get("optOutKeywords"),
      }),
    });
    toast.success("Settings saved");
    setSaving(false);
  }

  if (loading || !profile) {
    return <div className="flex h-64 items-center justify-center"><RefreshCw className="h-6 w-6 animate-spin text-gray-400" /></div>;
  }

  let hours = { start: "08:00", end: "18:00" };
  try {
    hours = JSON.parse(profile.businessHours);
  } catch { /* use defaults */ }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Settings</h1>
        <p className="text-muted-foreground">Manage your business profile and preferences</p>
      </div>

      <form onSubmit={handleSave}>
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Settings className="h-5 w-5" />
              Business Profile
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label htmlFor="name">Business Name</Label>
              <Input id="name" name="name" defaultValue={profile.name} />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="phone">Phone Number</Label>
                <Input id="phone" name="phone" type="tel" defaultValue={profile.phone} />
              </div>
              <div>
                <Label htmlFor="email">Email</Label>
                <Input id="email" name="email" type="email" defaultValue={profile.email} />
              </div>
            </div>

            <Separator />

            <div>
              <h3 className="mb-2 font-medium">Business Hours (SMS Sending Window)</h3>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="startHour">Start Time</Label>
                  <Input id="startHour" name="startHour" type="time" defaultValue={hours.start} />
                </div>
                <div>
                  <Label htmlFor="endHour">End Time</Label>
                  <Input id="endHour" name="endHour" type="time" defaultValue={hours.end} />
                </div>
              </div>
            </div>

            <Separator />

            <div>
              <Label htmlFor="optOutKeywords">Opt-Out Keywords (comma-separated)</Label>
              <Input
                id="optOutKeywords"
                name="optOutKeywords"
                defaultValue={profile.optOutKeywords}
                placeholder="STOP, UNSUBSCRIBE, CANCEL"
              />
              <p className="mt-1 text-xs text-muted-foreground">
                When a contact replies with any of these keywords, they will be automatically opted out
              </p>
            </div>

            <Button type="submit" className="bg-purple-600 hover:bg-purple-700" disabled={saving}>
              <Save className="mr-2 h-4 w-4" />
              {saving ? "Saving..." : "Save Settings"}
            </Button>
          </CardContent>
        </Card>
      </form>
    </div>
  );
}
