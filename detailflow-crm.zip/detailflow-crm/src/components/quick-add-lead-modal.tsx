"use client";

import { useState } from "react";
import { Plus } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";

const sources = ["Google Ads", "Facebook", "Instagram", "Referral", "Walk-in", "Other"];
const services = [
  "Full Detail",
  "Interior Only",
  "Exterior Only",
  "Ceramic Coating",
  "Paint Correction",
];

export function QuickAddLeadModal() {
  const [open, setOpen] = useState(false);
  const [loading, setLoading] = useState(false);

  async function onSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setLoading(true);
    const form = new FormData(e.currentTarget);
    const data = {
      firstName: form.get("firstName"),
      lastName: form.get("lastName") || "",
      phone: form.get("phone"),
      email: form.get("email") || "",
      source: form.get("source") || "Other",
      vehicleYear: form.get("vehicleYear") || "",
      vehicleMake: form.get("vehicleMake") || "",
      vehicleModel: form.get("vehicleModel") || "",
      serviceInterest: form.get("serviceInterest") || "",
      notes: form.get("notes") || "",
    };

    try {
      const res = await fetch("/api/contacts", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      if (!res.ok) throw new Error("Failed to add lead");
      toast.success("Lead added! First nurture message queued.");
      setOpen(false);
      window.dispatchEvent(new Event("lead-added"));
    } catch {
      toast.error("Failed to add lead");
    } finally {
      setLoading(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button
          className="fixed bottom-6 right-6 z-40 h-14 w-14 rounded-full bg-purple-600 shadow-lg hover:bg-purple-700"
          size="icon"
        >
          <Plus className="h-6 w-6" />
        </Button>
      </DialogTrigger>
      <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-lg">
        <DialogHeader>
          <DialogTitle>Add New Lead</DialogTitle>
        </DialogHeader>
        <form onSubmit={onSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="firstName">First Name *</Label>
              <Input id="firstName" name="firstName" required />
            </div>
            <div>
              <Label htmlFor="lastName">Last Name</Label>
              <Input id="lastName" name="lastName" />
            </div>
          </div>
          <div>
            <Label htmlFor="phone">Phone *</Label>
            <Input id="phone" name="phone" type="tel" required />
          </div>
          <div>
            <Label htmlFor="email">Email</Label>
            <Input id="email" name="email" type="email" />
          </div>
          <div className="grid grid-cols-3 gap-4">
            <div>
              <Label htmlFor="vehicleYear">Year</Label>
              <Input id="vehicleYear" name="vehicleYear" placeholder="2024" />
            </div>
            <div>
              <Label htmlFor="vehicleMake">Make *</Label>
              <Input id="vehicleMake" name="vehicleMake" required placeholder="Toyota" />
            </div>
            <div>
              <Label htmlFor="vehicleModel">Model *</Label>
              <Input id="vehicleModel" name="vehicleModel" required placeholder="Camry" />
            </div>
          </div>
          <div>
            <Label htmlFor="serviceInterest">Service Interest *</Label>
            <Select name="serviceInterest" required>
              <SelectTrigger>
                <SelectValue placeholder="Select service" />
              </SelectTrigger>
              <SelectContent>
                {services.map((s) => (
                  <SelectItem key={s} value={s}>
                    {s}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label htmlFor="source">Source</Label>
            <Select name="source">
              <SelectTrigger>
                <SelectValue placeholder="Select source" />
              </SelectTrigger>
              <SelectContent>
                {sources.map((s) => (
                  <SelectItem key={s} value={s}>
                    {s}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label htmlFor="notes">Notes</Label>
            <Textarea id="notes" name="notes" rows={2} />
          </div>
          <Button type="submit" className="w-full bg-purple-600 hover:bg-purple-700" disabled={loading}>
            {loading ? "Adding..." : "Add Lead & Start Nurture"}
          </Button>
        </form>
      </DialogContent>
    </Dialog>
  );
}
